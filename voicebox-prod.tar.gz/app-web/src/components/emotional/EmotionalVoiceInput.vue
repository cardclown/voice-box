<template>
  <div class="emotional-voice-input">
    <p>情感语音输入组件（待实现）</p>
  </div>
</template>

<script setup>
// 临时占位组件
</script>

<style scoped>
.emotional-voice-input {
  padding: var(--spacing-md);
  text-align: center;
  color: var(--text-secondary);
}
</style>
