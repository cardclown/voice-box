<template>
  <div class="emotional-voice-container">
    <div class="emotional-voice-header">
      <h1 class="page-title">情感语音交互</h1>
      <p class="page-subtitle">体验智能情感识别与个性化语音合成</p>
    </div>

    <div class="emotional-voice-content">
      <div class="left-panel">
        <div class="voice-input-section">
          <h2 class="section-title">语音输入</h2>
          <EmotionalVoiceInput 
            @voice-analyzed="handleVoiceAnalyzed"
            @error="handleError"
          />
        </div>

        <div class="emotion-feedback-section">
          <h2 class="section-title">实时情绪反馈</h2>
          <EmotionFeedback :emotion-data="currentEmotion" />
        </div>
      </div>

      <div class="right-panel">
        <div class="language-section">
          <h2 class="section-title">语言设置</h2>
          <LanguageSelector 
            :user-id="userId"
            @language-changed="handleLanguageChanged"
          />
        </div>
        
        <div class="tags-section">
          <h2 class="section-title">情感标签</h2>
          <TagVisualization :tags="userTags" />
        </div>

        <div class="statistics-section">
          <h2 class="section-title">情感统计</h2>
          <EmotionStatistics :user-id="userId" />
        </div>
      </div>
    </div>

    <div class="history-section">
      <h2 class="section-title">对话历史</h2>
      <EmotionHistory :user-id="userId" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import EmotionalVoiceInput from '../components/emotional/EmotionalVoiceInput.vue'
import EmotionFeedback from '../components/emotional/EmotionFeedback.vue'
import TagVisualization from '../components/emotional/TagVisualization.vue'
import EmotionStatistics from '../components/emotional/EmotionStatistics.vue'
import EmotionHistory from '../components/emotional/EmotionHistory.vue'
import LanguageSelector from '../components/emotional/LanguageSelector.vue'
import { useEmotionalVoiceStore } from '../stores/emotionalVoiceStore'

const store = useEmotionalVoiceStore()
const userId = ref(1)
const currentEmotion = ref(null)
const userTags = ref({})

const handleVoiceAnalyzed = (result) => {
  currentEmotion.value = result
  store.setCurrentEmotion(result)
  if (result.tags) {
    userTags.value = result.tags
  }
}

const handleError = (error) => {
  console.error('语音分析错误:', error)
}

const handleLanguageChanged = (language) => {
  console.log('语言已切换:', language)
  // 重新加载用户画像以获取新语言的配置
  store.loadProfile(userId.value)
}

onMounted(() => {
  // 加载用户画像
  store.loadProfile(userId.value)
})
</script>

<style scoped>
.emotional-voice-container {
  padding: var(--spacing-lg);
  max-width: 1400px;
  margin: 0 auto;
}

.emotional-voice-header {
  text-align: center;
  margin-bottom: var(--spacing-xl);
}

.page-title {
  font-size: 2rem;
  margin: 0 0 var(--spacing-sm) 0;
}

.page-subtitle {
  color: var(--text-secondary);
  margin: 0;
}

.emotional-voice-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--spacing-lg);
  margin-bottom: var(--spacing-xl);
}

.section-title {
  font-size: 1.25rem;
  margin: 0 0 var(--spacing-md) 0;
}

.voice-input-section,
.emotion-feedback-section,
.language-section,
.tags-section,
.statistics-section,
.history-section {
  background: var(--bg-primary);
  padding: var(--spacing-lg);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.language-section {
  margin-bottom: var(--spacing-lg);
}

@media (max-width: 768px) {
  .emotional-voice-content {
    grid-template-columns: 1fr;
  }
}
</style>
