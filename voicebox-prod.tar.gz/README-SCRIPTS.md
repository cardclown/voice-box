# VoiceBox 启动脚本使用指南

## 📋 脚本列表

### 1. `start-all.sh` - 一键启动
**功能**: 按正确顺序启动所有服务（后端 + 前端）

**使用方法**:
```bash
./start-all.sh
```

**执行步骤**:
1. ✅ 检查环境（Maven、Node.js、npm）
2. 🔨 编译后端项目（`mvn clean install`）
3. 📦 检查并安装前端依赖（如需要）
4. 🚀 启动后端服务（端口 10088）
5. 🎨 启动前端服务（端口 5173）

**特点**:
- 自动检测端口占用并清理
- 等待服务完全启动后才继续
- 后台运行，不阻塞终端
- 生成 PID 文件便于管理

---

### 2. `stop-all.sh` - 停止所有服务
**功能**: 优雅地停止所有运行中的服务

**使用方法**:
```bash
./stop-all.sh
```

**执行步骤**:
1. 🛑 停止后端服务
2. 🛑 停止前端服务
3. 🧹 清理残留进程（如有）
4. 🗑️ 删除 PID 文件

---

### 3. `restart-all.sh` - 重启所有服务
**功能**: 停止后重新启动所有服务

**使用方法**:
```bash
./restart-all.sh
```

**适用场景**:
- 修改了代码需要重新加载
- 服务出现异常需要重启
- 配置文件更新后

---

### 4. `status.sh` - 查看服务状态
**功能**: 实时查看所有服务的运行状态

**使用方法**:
```bash
./status.sh
```

**显示信息**:
- ✅ 服务运行状态（运行中/已停止）
- 🔢 进程 PID
- ❤️ 健康检查结果
- 📊 日志文件大小
- 🌐 服务访问地址

---

## 🎯 快速开始

### 首次使用
```bash
# 1. 赋予脚本执行权限（已自动完成）
chmod +x *.sh

# 2. 启动所有服务
./start-all.sh

# 3. 等待启动完成后访问
# 前端: http://localhost:5173
# 后端: http://localhost:10088
```

### 日常使用
```bash
# 启动服务
./start-all.sh

# 查看状态
./status.sh

# 停止服务
./stop-all.sh

# 重启服务
./restart-all.sh
```

---

## 📝 日志文件

### 查看日志
```bash
# 查看后端日志
tail -f backend.log

# 查看前端日志
tail -f frontend.log

# 查看最近 100 行
tail -n 100 backend.log
```

### 清理日志
```bash
# 清空日志文件
> backend.log
> frontend.log

# 或删除日志文件
rm -f backend.log frontend.log
```

---

## 🔧 故障排查

### 问题 1: 端口被占用
**现象**: 启动失败，提示端口已被占用

**解决方案**:
```bash
# 方案 1: 使用停止脚本清理
./stop-all.sh

# 方案 2: 手动查找并杀死进程
lsof -ti:10088 | xargs kill -9  # 后端
lsof -ti:5173 | xargs kill -9   # 前端
```

### 问题 2: 编译失败
**现象**: 启动脚本在编译阶段失败

**解决方案**:
```bash
# 手动编译查看详细错误
mvn clean install -DskipTests

# 如果是依赖问题，清理 Maven 缓存
rm -rf ~/.m2/repository/com/example/voicebox
mvn clean install -DskipTests
```

### 问题 3: 前端依赖安装失败
**现象**: npm install 报错

**解决方案**:
```bash
cd app-web

# 清理缓存重新安装
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

### 问题 4: 服务启动但无法访问
**现象**: 进程存在但 API 不响应

**解决方案**:
```bash
# 1. 查看日志
tail -f backend.log

# 2. 检查配置文件
cat config.properties

# 3. 重启服务
./restart-all.sh
```

---

## ⚙️ 配置说明

### 端口配置
- **后端**: 10088（可在 `application.properties` 修改）
- **前端**: 5173（可在 `vite.config.js` 修改）

### 环境要求
- **Java**: 11 或更高版本
- **Maven**: 3.6 或更高版本
- **Node.js**: 16 或更高版本
- **npm**: 8 或更高版本

---

## 💡 高级用法

### 只启动后端
```bash
cd /Users/jd/mydesk/cursorFiles/voice-box
mvn spring-boot:run -pl app-device -Dspring-boot.run.main-class=com.example.voicebox.app.device.DeviceApp
```

### 只启动前端
```bash
cd app-web
npm run dev
```

### 生产环境部署
```bash
# 1. 编译后端
mvn clean package -DskipTests

# 2. 运行 JAR
java -jar app-device/target/app-device-0.0.1-SNAPSHOT.jar

# 3. 构建前端
cd app-web
npm run build

# 4. 使用 Nginx 或其他服务器部署 dist 目录
```

---

## 🆘 获取帮助

如果遇到问题：
1. 查看日志文件：`backend.log` 和 `frontend.log`
2. 运行状态检查：`./status.sh`
3. 查看详细错误：手动运行编译和启动命令

---

## 📌 注意事项

1. **不要直接 Ctrl+C**: 启动脚本会在后台运行服务，直接 Ctrl+C 不会停止服务，请使用 `./stop-all.sh`
2. **PID 文件**: 脚本会生成 `backend.pid` 和 `frontend.pid`，请勿手动删除
3. **日志轮转**: 日志文件会持续增长，建议定期清理
4. **权限问题**: 如果脚本无法执行，运行 `chmod +x *.sh`

---

## 🎉 完成！

现在你可以使用这些脚本轻松管理 VoiceBox 项目了！

**快速命令**:
- 启动: `./start-all.sh`
- 停止: `./stop-all.sh`
- 重启: `./restart-all.sh`
- 状态: `./status.sh`

