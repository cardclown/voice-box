package com.example.voicebox.cloud;

public enum VoiceStyle {
    DEFAULT,
    HAPPY,
    SAD,
    CALM,
    SERIOUS
}
