package com.example.voicebox.hardware;

public enum DeviceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}
