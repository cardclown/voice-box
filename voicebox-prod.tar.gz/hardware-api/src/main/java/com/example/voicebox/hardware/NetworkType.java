package com.example.voicebox.hardware;

public enum NetworkType {
    OFFLINE,
    WIFI,
    CELLULAR
}
