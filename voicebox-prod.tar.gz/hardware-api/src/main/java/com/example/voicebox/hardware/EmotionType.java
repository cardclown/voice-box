package com.example.voicebox.hardware;

public enum EmotionType {
    NEUTRAL,
    HAPPY,
    SAD,
    ANGRY,
    SURPRISED,
    CALM
}
