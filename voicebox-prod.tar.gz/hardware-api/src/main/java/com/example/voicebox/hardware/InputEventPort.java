package com.example.voicebox.hardware;

public interface InputEventPort {

    void registerListener(InputEventListener listener);
}
