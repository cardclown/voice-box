package com.example.voicebox.core;

public class DeviceContext {
    // placeholder for device/user specific context
}
