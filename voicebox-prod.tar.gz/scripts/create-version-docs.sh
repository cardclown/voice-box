#!/bin/bash

# VoiceBox 版本文档生成脚本
# 用法: ./scripts/create-version-docs.sh <version> <feature-name>
# 示例: ./scripts/create-version-docs.sh v1.1 personality-analysis

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查参数
if [ $# -lt 2 ]; then
    echo -e "${RED}错误: 缺少参数${NC}"
    echo "用法: $0 <version> <feature-name>"
    echo "示例: $0 v1.1 personality-analysis"
    exit 1
fi

VERSION=$1
FEATURE_NAME=$2
DIR_NAME="${VERSION}-${FEATURE_NAME}"
BASE_DIR="docs/versions/${DIR_NAME}"

# 检查目录是否已存在
if [ -d "$BASE_DIR" ]; then
    echo -e "${RED}错误: 目录 ${BASE_DIR} 已存在${NC}"
    exit 1
fi

# 创建目录
echo -e "${GREEN}创建版本目录: ${BASE_DIR}${NC}"
mkdir -p "$BASE_DIR"

# 获取当前日期
CURRENT_DATE=$(date +%Y-%m-%d)

# 生成 requirements.md
echo -e "${YELLOW}生成 requirements.md...${NC}"
cat > "${BASE_DIR}/requirements.md" << EOF
# ${VERSION} ${FEATURE_NAME} - 需求文档

**版本**: ${VERSION}  
**创建日期**: ${CURRENT_DATE}  
**状态**: 📝 规划中  
**优先级**: P0 (最高)

---

## 📋 功能概述

[在此描述功能的整体概述]

## 🎯 业务目标

1. **目标1**: [描述业务目标]
2. **目标2**: [描述业务目标]
3. **目标3**: [描述业务目标]

## 👥 用户故事

### 故事1: [故事标题]

**作为** [角色]  
**我希望** [功能]  
**以便** [价值]

**验收标准**:
- 标准1
- 标准2
- 标准3

### 故事2: [故事标题]

**作为** [角色]  
**我希望** [功能]  
**以便** [价值]

**验收标准**:
- 标准1
- 标准2
- 标准3

## ✅ 功能需求

### FR1: [功能需求1]

**优先级**: P0

**描述**: [详细描述]

**详细需求**:
1. 需求点1
2. 需求点2
3. 需求点3

**验收标准**:
- 标准1
- 标准2
- 标准3

### FR2: [功能需求2]

**优先级**: P1

**描述**: [详细描述]

**详细需求**:
1. 需求点1
2. 需求点2
3. 需求点3

**验收标准**:
- 标准1
- 标准2
- 标准3

## 🔒 非功能性需求

### NFR1: 性能要求

- 响应时间: <Xms
- 并发用户数: X+
- 吞吐量: X QPS

### NFR2: 可用性要求

- 系统可用性: 99.X%
- 数据持久性: 99.XX%

### NFR3: 安全性要求

- 数据加密
- 访问控制
- 审计日志

### NFR4: 兼容性要求

- 浏览器支持
- 移动端支持
- 第三方集成

## 🚫 约束条件

### 技术约束

1. 约束1
2. 约束2

### 业务约束

1. 约束1
2. 约束2

### 时间约束

1. 开发周期: X周
2. 测试周期: X周
3. 上线时间: 第X周

## 📊 成功指标

### 业务指标

- 指标1: >X%
- 指标2: >X%

### 技术指标

- 指标1: <Xms
- 指标2: >XX%

## 🔄 未来扩展

### v${VERSION}.1 计划

- 扩展功能1
- 扩展功能2

---

**文档维护者**: VoiceBox开发团队  
**最后更新**: ${CURRENT_DATE}  
**审核状态**: 待审核
EOF

# 生成 design.md
echo -e "${YELLOW}生成 design.md...${NC}"
cat > "${BASE_DIR}/design.md" << EOF
# ${VERSION} ${FEATURE_NAME} - 设计文档

**版本**: ${VERSION}  
**创建日期**: ${CURRENT_DATE}  
**状态**: 📝 规划中  
**设计负责人**: VoiceBox架构团队

---

## 📐 架构设计

### 系统架构图

\`\`\`
[在此绘制系统架构图]
\`\`\`

### 技术栈选型

**后端**:
- 框架: Spring Boot 2.7+
- 数据库: MySQL 8.0+
- 缓存: Redis 6.0+

**前端**:
- 框架: Vue 3 + Vite
- 状态管理: Pinia
- HTTP客户端: Axios

## 🗄️ 数据模型设计

### 表1: [表名]

\`\`\`sql
CREATE TABLE table_name (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    -- 字段定义
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='表说明';
\`\`\`

## 🔧 核心组件设计

### 1. 组件1

**职责**: [描述组件职责]

**核心方法**:

\`\`\`java
@Service
public class ComponentService {
    // 实现代码
}
\`\`\`

### 2. 组件2

**职责**: [描述组件职责]

**核心方法**:

\`\`\`java
@Service
public class ComponentService {
    // 实现代码
}
\`\`\`

## 🔐 安全设计

### 数据加密

- 敏感数据加密方案
- 传输加密方案

### 访问控制

- 身份验证机制
- 权限控制机制

## ⚡ 性能优化

### 缓存策略

- 缓存层级
- 缓存更新策略
- 缓存失效策略

### 数据库优化

- 索引设计
- 查询优化
- 分库分表

## 📊 监控和日志

### 监控指标

- 业务指标
- 技术指标
- 告警规则

### 日志设计

- 日志级别
- 日志格式
- 日志存储

---

**文档维护者**: VoiceBox架构团队  
**最后更新**: ${CURRENT_DATE}  
**审核状态**: 待审核
EOF

# 生成 implementation-plan.md
echo -e "${YELLOW}生成 implementation-plan.md...${NC}"
cat > "${BASE_DIR}/implementation-plan.md" << EOF
# ${VERSION} ${FEATURE_NAME} - 实施计划

**版本**: ${VERSION}  
**创建日期**: ${CURRENT_DATE}  
**计划开始**: [开始日期]  
**计划完成**: [完成日期]  
**总工期**: X周

---

## 📅 开发计划

### 第1周: [阶段名称]

#### 任务1.1: [任务名称] (X天)
- **负责人**: [负责人]
- **工作内容**:
  - 工作项1
  - 工作项2
  - 工作项3
- **交付物**: [交付物列表]
- **验收标准**: [验收标准]

#### 任务1.2: [任务名称] (X天)
- **负责人**: [负责人]
- **工作内容**:
  - 工作项1
  - 工作项2
- **交付物**: [交付物列表]
- **验收标准**: [验收标准]

### 第2周: [阶段名称]

#### 任务2.1: [任务名称] (X天)
- **负责人**: [负责人]
- **工作内容**:
  - 工作项1
  - 工作项2
- **交付物**: [交付物列表]
- **验收标准**: [验收标准]

## 📊 资源分配

| 角色 | 人员 | 工作量 |
|------|------|--------|
| 后端开发 | 2人 | X人天 |
| 前端开发 | 1人 | X人天 |
| 测试工程师 | 1人 | X人天 |

## 🎯 里程碑

| 里程碑 | 日期 | 交付物 |
|--------|------|--------|
| 需求评审完成 | [日期] | 需求文档 |
| 设计评审完成 | [日期] | 设计文档 |
| 开发完成 | [日期] | 功能代码 |
| 测试完成 | [日期] | 测试报告 |
| 上线发布 | [日期] | 生产环境 |

## ⚠️ 风险评估

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|----------|
| 风险1 | 高 | 中 | 应对措施 |
| 风险2 | 中 | 低 | 应对措施 |

## ✅ 测试计划

### 单元测试
- 测试覆盖率目标: >80%
- 测试框架: JUnit 5

### 集成测试
- 测试场景: [场景列表]
- 测试工具: [工具列表]

### 性能测试
- 并发用户数: X
- 响应时间要求: <Xms
- 测试工具: JMeter

---

**文档维护者**: VoiceBox项目管理团队  
**最后更新**: ${CURRENT_DATE}  
**审核状态**: 待审核
EOF

# 生成 api-spec.md
echo -e "${YELLOW}生成 api-spec.md...${NC}"
cat > "${BASE_DIR}/api-spec.md" << EOF
# ${VERSION} ${FEATURE_NAME} - API规格说明

**版本**: ${VERSION}  
**创建日期**: ${CURRENT_DATE}  
**Base URL**: \`https://api.voicebox.com/v1\`

---

## 📡 API列表

### 1. [API名称]

**端点**: \`POST /endpoint\`

**描述**: [API功能描述]

**请求头**:
\`\`\`
Content-Type: application/json
Authorization: Bearer {token}
\`\`\`

**请求体**:
\`\`\`json
{
  "field1": "value1",
  "field2": "value2"
}
\`\`\`

**响应**:
\`\`\`json
{
  "code": 200,
  "message": "success",
  "data": {
    "field1": "value1",
    "field2": "value2"
  }
}
\`\`\`

**错误码**:
| 错误码 | 说明 |
|--------|------|
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 500 | 服务器错误 |

### 2. [API名称]

**端点**: \`GET /endpoint/{id}\`

**描述**: [API功能描述]

**路径参数**:
- \`id\`: [参数说明]

**查询参数**:
- \`param1\`: [参数说明]
- \`param2\`: [参数说明]

**响应**:
\`\`\`json
{
  "code": 200,
  "message": "success",
  "data": {
    "field1": "value1",
    "field2": "value2"
  }
}
\`\`\`

## 📝 数据模型

### Model1

\`\`\`json
{
  "field1": "string",
  "field2": "number",
  "field3": "boolean"
}
\`\`\`

**字段说明**:
| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| field1 | string | 是 | 字段说明 |
| field2 | number | 否 | 字段说明 |
| field3 | boolean | 否 | 字段说明 |

---

**文档维护者**: VoiceBox API团队  
**最后更新**: ${CURRENT_DATE}
EOF

# 更新版本列表
echo -e "${YELLOW}更新版本列表...${NC}"
# 这里可以添加自动更新 docs/versions/README.md 的逻辑

echo -e "${GREEN}✅ 版本文档创建完成！${NC}"
echo -e "${GREEN}目录位置: ${BASE_DIR}${NC}"
echo ""
echo -e "${YELLOW}下一步:${NC}"
echo "1. 编辑 ${BASE_DIR}/requirements.md 填写需求详情"
echo "2. 编辑 ${BASE_DIR}/design.md 填写设计详情"
echo "3. 编辑 ${BASE_DIR}/implementation-plan.md 填写实施计划"
echo "4. 编辑 ${BASE_DIR}/api-spec.md 填写API规格"
echo ""
echo -e "${GREEN}祝开发顺利！🚀${NC}"
EOF

chmod +x scripts/create-version-docs.sh

echo "✅ 脚本创建完成！"
