#!/bin/bash
# 快速连接到服务器

ssh voicebox-server
