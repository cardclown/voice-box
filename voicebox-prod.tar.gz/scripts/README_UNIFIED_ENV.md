# 统一环境配置和部署脚本

## 📁 脚本说明

### 1. setup-unified-environment.sh
**位置**：`scripts/server/setup-unified-environment.sh`  
**用途**：在服务器上配置统一的Java 1.8和Maven 3.6.3环境  
**执行位置**：服务器上（需要root权限）

### 2. deploy-with-unified-env.sh
**位置**：`scripts/deploy-with-unified-env.sh`  
**用途**：一键配置服务器环境并部署应用  
**执行位置**：本地

---

## 🚀 快速开始

### 方式1：一键部署（推荐）

在本地项目根目录执行：

```bash
./scripts/deploy-with-unified-env.sh
```

这个脚本会自动：
1. ✅ 检查本地环境（Java 1.8 + Maven 3.6.3）
2. ✅ 上传环境配置脚本到服务器
3. ✅ 在服务器上配置统一环境
4. ✅ 编译项目
5. ✅ 部署到服务器
6. ✅ 启动服务

### 方式2：分步执行

#### 步骤1：配置服务器环境

```bash
# 上传脚本到服务器
scp scripts/server/setup-unified-environment.sh root@129.211.180.183:/tmp/

# SSH连接到服务器
ssh root@129.211.180.183

# 执行配置脚本（需要root权限）
chmod +x /tmp/setup-unified-environment.sh
sudo /tmp/setup-unified-environment.sh

# 重新加载环境变量
source /etc/profile

# 验证环境
java -version  # 应该显示 1.8.0
mvn -version   # 应该显示 3.6.3
```

#### 步骤2：编译和部署

```bash
# 在本地编译
mvn clean package -DskipTests

# 部署到服务器
./deploy/deploy-prod.sh
```

---

## 📋 环境要求

| 组件 | 版本 | 说明 |
|------|------|------|
| Java | 1.8 | 统一使用Java 8 |
| Maven | 3.6.3 | 统一使用Maven 3.6.3 |
| 操作系统 | CentOS 7+ | 服务器操作系统 |

---

## ⚠️ 注意事项

1. **备份**：脚本会自动备份现有配置到 `/root/environment-backup-YYYYMMDD_HHMMSS/`

2. **权限**：环境配置脚本需要root权限执行

3. **网络**：需要能够访问Maven中央仓库或配置国内镜像

4. **环境变量**：配置完成后需要重新加载环境变量或重新登录

---

## 🔍 验证环境

### 本地环境

```bash
java -version
# 输出应包含: java version "1.8.0"

mvn -version
# 输出应包含: Apache Maven 3.6.3
```

### 服务器环境

```bash
ssh root@129.211.180.183 "java -version && mvn -version"
```

---

## 🐛 故障排查

### 问题1：Maven下载失败

**解决方案**：
```bash
# 使用国内镜像
cd /tmp
wget https://mirrors.tuna.tsinghua.edu.cn/apache/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
```

### 问题2：环境变量不生效

**解决方案**：
```bash
# 重新加载
source /etc/profile

# 或者重新登录
exit
ssh root@129.211.180.183
```

### 问题3：权限不足

**解决方案**：
```bash
# 使用sudo执行
sudo /tmp/setup-unified-environment.sh
```

---

## 📚 相关文档

- [统一环境配置指南](../docs/UNIFIED_ENVIRONMENT_GUIDE.md) - 详细的环境配置文档
- [部署指南](../deploy/README.md) - 部署流程说明
- [快速开始](../QUICK_START.md) - 项目快速开始指南

---

## 💡 提示

- 首次配置服务器环境时，建议使用方式1（一键部署）
- 后续部署可以直接使用 `./deploy/deploy-prod.sh`
- 定期检查环境版本，确保本地和服务器一致

---

**最后更新**：2024-11-30
